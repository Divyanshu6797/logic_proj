# logic_in_cs_proj
this is my logic in computer science project code

this checks if the proof given is valid or not.
this code is documeted using doxigen
