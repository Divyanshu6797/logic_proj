@page page2 code design

the code has different functions for different rules

code stats in the main function and every input is split in 2 parts the rule and the statement

the statement is stored in a global variable

a function is called depending on the rule 
the function checks weather the statement using the rule is same .if same it returns 1 ,otherwise it returns 0.

if a function returns 0 then the output will be invalid proof after all statements are typed
 