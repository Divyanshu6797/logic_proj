@page page3 example outputs

@tableofcontents

@section and_intro 

this is valid

![](2022-12-02.png)

this is invalid because no bracket

![](Screenshot_l_2.png)

@section and_elem

this is valid

![](Screenshot_l_3.png)

@section premice

this is valid

![](Screenshot_pre1_l.png)

this is invalid 

![](Screenshot_l_pre2.png)


@section orintro

this is valid

![](Screenshot_orintro.png)

@section implelem

this is valid

![](Screenshot_l_implelem1.png)

this is invalid

![](Screensho_l_implelem2.png)

@section mt

this is valid

![](Screenshot_mt.png)

