@mainpage  logic assignment 2 documentation 


future additions here : @ref page2.md

code design here : @ref page3.md

code algo here : @ref page4.md

example outputs here : @ref page5.md